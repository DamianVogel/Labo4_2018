export class JuegoAgilidad {
}
