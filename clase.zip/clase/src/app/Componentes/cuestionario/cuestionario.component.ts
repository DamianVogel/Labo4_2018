import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-cuestionario',
  templateUrl: './cuestionario.component.html',
  styleUrls: ['./cuestionario.component.css']
})
export class CuestionarioComponent implements OnInit {
  @Input() tema: string;
  cuestionario:string;
  @Output() emiterCuestionario:EventEmitter<any> = new EventEmitter<any>();
  constructor() { }

  ngOnInit() {
  }

  AceptarCuestionario($event) {
    this.emiterCuestionario.emit($event);
  }

}
