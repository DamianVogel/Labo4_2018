import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-pregunta',
  templateUrl: './pregunta.component.html',
  styleUrls: ['./pregunta.component.css']
})
export class PreguntaComponent implements OnInit {

  @Input() tema: string;
  @Input() cuestionario: string;
  respuesta:string;

  @Output() emiterPregunta:EventEmitter<any> = new EventEmitter<any>();
  constructor() { }

  ngOnInit() {
  }

  AceptarPregunta() {
    if(this.respuesta == undefined || this.respuesta == "")
    {
      this.respuesta="";
    }
    
    this.emiterPregunta.emit(this.respuesta);
  }
}
