import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-tema',
  templateUrl: './tema.component.html',
  styleUrls: ['./tema.component.css']
})
export class TemaComponent implements OnInit {
 tema:string;
 contador:number;
 
 constructor() { 
   this.contador = 0;
 }

 ngOnInit() {
 }

 AceptarTema($event) {
   alert($event);
   this.contador++;
 }

}
