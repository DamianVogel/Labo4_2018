import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms'
import { AppComponent } from './app.component';
import { TemaComponent } from './Componentes/tema/tema.component';
import { CuestionarioComponent } from './Componentes/cuestionario/cuestionario.component';
import { PreguntaComponent } from './Componentes/pregunta/pregunta.component';

@NgModule({
  declarations: [
    AppComponent,
    TemaComponent,
    CuestionarioComponent,
    PreguntaComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
