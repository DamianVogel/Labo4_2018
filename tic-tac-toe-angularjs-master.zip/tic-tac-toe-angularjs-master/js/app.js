(function(){
    var app = angular.module("codesandtags",  []);

    app.controller('userController', function(){
        this.user = user;
    });

    var user ={
        name : "Edwin Torres",
        rol : "Creative Developer",
        salary : 450000
    }
})();


