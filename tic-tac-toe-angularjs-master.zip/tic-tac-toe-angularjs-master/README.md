# tic-tac-toe-angularjs

This is the Tic-Tac-Toe Game using the AngularJS Framework, Bootstrap, jQuery and JavaScript :)

